import express from 'express';
import fs from 'fs';
import bodyParser from 'body-parser';
import cors from 'cors';

const app = express();
const port = 9000;
const fileMessage = 'message'

const sendFile = () => {
    try {
        console.log('server main - oczyt pliku')
        const data =  fs.readFileSync(fileMessage, 'utf-8');
        return JSON.parse(data); // Przekształć dane na obiekt JSON
    } catch (error) {
        console.error('Błąd podczas odczytu pliku lub parsowania JSON:', error);
    }
}

const chkPass = async (userName, userPass) => {
    console.log('funkcja chkPass')

    const usersData = await fs.promises.readFile('users.json','utf-8');console.log(usersData)
    const usersBase = JSON.parse(usersData);

    for (let user of usersBase) {
        if ((user.name == userName) && (user.password == userPass)) {
            return true;
        }
    }
    return false;
}

app.use(cors());
app.use(bodyParser.json());

app.post('/pass',async (req, res) => {
    console.log('! pass ! ')
    const chkData = await req.body;
    console.log(chkData)
    const chk = await chkPass(chkData.name, chkData.pass);
    console.log(chk)
    if (chk) {
        res.json('correct')
    } else  {
        res.json('wrong')
    }
    // const toSave = await req.body;
    // let file;
    //
    // // Spróbuj odczytać istniejący plik
    // try {
    //     file = await sendFile();
    // } catch (error) {
    //     file = [];
    // }
    //
    // file.push(toSave);


    res.status(200)
})

app.get('/',async (req,res) => {
    let file = await sendFile();
    console.log('server main - wysyłka pliku: ')
    console.log(file)

    res.json(file) // Wysyłaj dane jako odpowiedź JSON
})

app.post('/',async (req, res) => {
    console.log('! saveFILE ')
    const toSave = await req.body;
    let file;

    // Spróbuj odczytać istniejący plik
    try {
        file = await sendFile();
    } catch (error) {
        file = [];
    }

    file.push(toSave);

    await fs.promises.writeFile(fileMessage, JSON.stringify(file), 'utf-8')
    res.status(200)
})






app.listen(port, '0.0.0.0', function () {
    console.log('Serwer nasłuchuje na porcie 9000.');
});
