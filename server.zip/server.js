import express from 'express';


const app = express();
const port = 2137;
const path = '../html/'

app.use(express.static(path));
// app.use(express.static('node-modules'));

app.listen(port, '0.0.0.0', function () {
    console.log('Serwer nasłuchuje na porcie 2137!');
});