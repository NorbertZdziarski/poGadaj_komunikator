let loggedUser;
let userName;
let userPass;
let userPost;
let serverIp = 'http://192.168.40.5:9000';
let fetchedData = [];

const fetchData = async () => {
    try {
        const response = await fetch(serverIp, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' },
        });
        const data = await response.json();
        fetchedData = data;
        displayMessages(fetchedData); // Wywołaj funkcję displayMessages po pobraniu danych
    } catch (error) {
        console.error('Error:', error);
    }
}

const displayMessages = (messages) => {
    console.log(loggedUser)
    if (!loggedUser) return;
    const disqs = document.getElementById('disqs');
    disqs.innerHTML = '';

    for(let i = messages.length - 1; i >= 0; i--) {
        const message = messages[i];
        const messageElement = document.createElement('div');

        if (userName == message.name) {
            messageElement.className = 'lineBoxUser'
            const textElement = document.createElement('p');
            textElement.className = 'messageBoxUser';
            textElement.textContent = message.message;
            messageElement.appendChild(textElement);

            const nameElement = document.createElement('p');
            nameElement.className = 'messageName';
            nameElement.textContent = message.name;
            messageElement.appendChild(nameElement);

            disqs.appendChild(messageElement);} else {
            messageElement.className = 'lineBox'

            const nameElement = document.createElement('p');
            nameElement.className = 'messageName';
            nameElement.textContent = message.name;
            messageElement.appendChild(nameElement);

            const textElement = document.createElement('p');
            textElement.className = 'messageBox';
            textElement.textContent = message.message;
            messageElement.appendChild(textElement);

            disqs.appendChild(messageElement);};


    }
}


const postMessage = async (message) => {
    console.log(' post message')
    const newMessage = { name: userName, message: message };

    try {
        const response = await fetch(serverIp, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newMessage) // Wysyłaj tylko nową wiadomość
        });
        await response.json();
        fetchData();
    } catch (error) {
        console.error('Error:', error);
    }
};


const handleUserPostSubmit = () => {
    document.getElementById('userPost').addEventListener('submit', async function(event) {
        event.preventDefault();
        userPost = document.getElementById('userPostText').value;
        await postMessage(userPost);
        document.getElementById('userPostText').value = ''
    });
}

const handleUserChat = async (user) => {
    await fetchData();
    if (fetchedData) {
        handleUserPostSubmit();
    }
}
const postLoginCheck = async (usName, usPass) => {
    console.log(' zapytanie o haslo')
    const sendData = { name: usName, pass: usPass };

    fetch(`${serverIp}/pass`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sendData)
    })// Odbieranie odpowiedzi i konwersja na JSON
        .then(response => response.json())

        .then(data => {
            if (data === "correct") {
                loggedUser = true;
            } else {

                loggedUser = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

};
    document.getElementById('userForm').addEventListener('submit', function (event) {
        event.preventDefault();
        userName = document.getElementById('firstName').value;
        userPass = document.getElementById('userPass').value;

        if (userName && userPass) {
            console.log('sprawdzanie danych')
            postLoginCheck(userName, userPass)

        }
        // Ukryj formularz po wprowadzeniu imienia
        document.getElementById('userForm').style.display = "none";

        // Wyświetl wprowadzone imię
        let welcomeMessage = document.getElementById('welcomeMessage');
        welcomeMessage.textContent = 'Witaj, ' + userName + '!';
        welcomeMessage.style.display = "block";

        handleUserChat(userName);
    });





const refreshDataAndDisplayMessages = () => {
    fetchData();
}
setInterval(refreshDataAndDisplayMessages, 2000);








if ((userName === 'n') && (userPass = 'h')) {
    document.getElementById('welcomeMessage').textContent = 'Witaj, ' + userName + '!';
    userChat(userName)
}
