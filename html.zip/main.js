import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.js';
import './index.scss';

console.log('main')

ReactDOM.render(
    React.createElement(
        React.StrictMode,
        null,
        React.createElement(App)
    ),
    document.getElementById('root')
);
